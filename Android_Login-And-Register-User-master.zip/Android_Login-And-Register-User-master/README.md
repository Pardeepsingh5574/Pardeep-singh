# Android - Login And Register User
This is a simple Android project for a basic registration system developed in Android with VolleyLibrary and PHP & MySQL.
This project is created with WAMP 2.4 and Android Studio 1.2.2.

To run this project, please upload Database Code (DB Backup.sql) in your Database (You may do it with PHP MyAdmin).

Then put the "android_login_api" folder in your Localhost Folder (In my case - it is www folder or wamp).
Then Check the config file (android_login_api\include\Config.php) and change the configuration if needed (no need to change for WAMP default configuration).

Then import the Android Project in Android Studio.
Change the "app/java/volley/Config_URL" file if needed (No need to change for WAMP default configuration).

Now try the app!!!!!!!!!!

Before start the app, make sure that WAPM is working perfectly and running.

Happy Coading...........
